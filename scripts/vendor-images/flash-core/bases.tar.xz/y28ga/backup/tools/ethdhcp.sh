killall udhcpc
udhcpc -i eth0 -b -s /backup/tools/default.script
